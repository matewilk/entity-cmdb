node ./js/index.js single-run
